package manager;

/**
 * Abstract class to represent a person.
 * 
 * @author mdixon
 *
 */
abstract class Person {

	/**
	 * The name of the person
	 */
	private String name;

	/**
	 * The home address of the person
	 */
	private String addr;

	/**
	 * The phone number of the person
	 */
	private String phone;

	/**
	 * The email address of the person.
	 */
	private String email;

	///////////////////////////////////////////////

	/**
	 * @return the home address of the person
	 */
	public String getAddr() {

		// TODO:Part1
		return "";
	}

	/**
	 * @param addr the home address of the person
	 */
	public void setAddr(String addr) {

		// TODO:Part1
	}

	/**
	 * @return the phone number of the person
	 */
	public String getPhone() {

		// TODO:Part1
		return "";
	}

	/**
	 * @param phone the phone number of the person
	 */
	public void setPhone(String phone) {

		// TODO:Part1
	}

	/**
	 * @return the email addr of the person
	 */
	public String getEmail() {

		// TODO:Part1
		return "";
	}

	/**
	 * @param email the email addr of the person
	 */
	public void setEmail(String email) {

		// TODO:Part1
	}

	/**
	 * @return the name of the person
	 */
	public String getName() {

		// TODO:Part1
		return "";
	}

	/**
	 * @param the new name of the person
	 */
	public void setName(String name) {

		// TODO:Part1
	}

	///////////////////////////////////////////////

	/**
	 * Constructor
	 * 
	 * @param name the name of the person
	 */
	Person(String name) {

		this.name = name;
	}
}
