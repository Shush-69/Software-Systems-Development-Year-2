package manager;

public class Office extends Property implements SecuredAccess {

	/**
	 * The stored security code.
	 */
	private String storedCode = "";	// TODO:Part2

	/**
	 * The number of incorrect code input attempts.
	 */
	private int incorrectAttempts;

	//////////////////////////////////////////////////////
	
	@Override
	public void setCode(String code) {
		
		// TODO:Part2
	}

	@Override
	public boolean checkCode(String code) {

		if (isLockedOut() || !code.equals(storedCode)) {
			// is locked out, or codes do not match
			
			// TODO:Part2 - increment attempts, then return false
		}

		
		// not locked, and codes match
		
		incorrectAttempts = 0;
		return true;
	}

	@Override
	public void resetToDefault() {

		// TODO:Part2
		incorrectAttempts = 0;
	}

	@Override
	public boolean isLockedOut() {

		// TODO:Part2 - check attempts again limit, return true if limit exceeded
		return false;
	}

	@Override
	public int getIncorrectAttempts() {

		// TODO:Part2
		return -1;
	}
	
	//////////////////////////////////////////////////////

	public Office(String address) {

		super(address);
	}

	
}
