package manager;

/**
 * Represents a Room within a {@link Hotel}.
 * 
 * @author mdixon
 *
 */
public class Room implements SecuredAccess {

	/**
	 * The room number within the hotel.
	 */
	private int roomNum;

	/**
	 * The stored security code.
	 */
	private String storedCode = "";	// TODO:Part2
	
	/**
	 * The current occupant of the room, null if the room is not occupied.
	 */
	private Guest occupant;
	
	////////////////////////////////
	
	@Override
	public void setCode(String code) {

		// TODO:Part2
	}

	@Override
	public boolean checkCode(String code) {

		// TODO:Part2
		return false;
	}
	
	@Override
	public void resetToDefault() {

		// TODO:Part2
	}

	@Override
	public boolean isLockedOut() {

		return false;
	}

	@Override
	public int getIncorrectAttempts() {

		// TODO:Part2
		return -1;
	}
	
	/**
	 * @return the roomNum
	 */
	public int getRoomNum() {
		
		// TODO:Part1
		return 0;
	}

	/**
	 * @param roomNum the roomNum to set
	 */
	public void setRoomNum(int roomNum) {
		
		// TODO:Part1
	}

	/**
	 * Sets the occupant of the room.
	 * 
	 * @param guest the guest which is to occupy the room
	 */
	public void setOccupant(Guest guest) {
		
		// TODO:Part3
	}
	
	/**
	 * Removes any occupant from the room.
	 */
	public void removeOccupant() {
		
		// TODO:Part3
	}
	
	/**
	 * 
	 * @return true if the room has an occupant
	 */
	public boolean hasOccupant() {
		
		// TODO:Part3
		return false;
	}
	
	////////////////////////////////
	
	/**
	 * Constructor.
	 * 
	 * @param roomNum the room number
	 */
	public Room(int roomNum) {

		// TODO:Part1 - set the roomNum attribute
	}


}
